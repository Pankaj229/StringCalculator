package com.cybage.controllers;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.SendResult;

import org.apache.catalina.core.ApplicationContext;

import com.cybage.pojo.FoodItem;
import com.cybage.pojo.Restaurant;
import com.cybage.service.FoodItemService;
import com.cybage.service.FoodItemServiceImpl;
import com.cybage.service.RestaurantMenuService;
import com.cybage.service.RestaurantMenuServiceImpl;
import com.cybage.service.RestaurantService;
import com.cybage.service.RestaurantServiceImpl;


@WebServlet(urlPatterns= {
		"/Restaurants/home","/Restaurants/addFoodCategory","/Restaurants/deleteFoodCategory",
		"/Restaurants/updateFoodCategory","/Restaurants/viewFoodCategory","/Restaurants/selectedFoodCategory",
		"/Restaurants/viewFoodItems","/Restaurants/addFoodItem","/Restaurants/selectedFoodItem","/Restaurants/updateFoodItem"})
public class RestaurantController extends HttpServlet {
	private static final long serialVersionUID = 1L;
		
       public RestaurantMenuService menuService=new RestaurantMenuServiceImpl();
       public RestaurantService restaurantService=new RestaurantServiceImpl();
       public FoodItemService foodService=new FoodItemServiceImpl();
       
    
    public RestaurantController() {
        super();
       
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getServletPath();
		RequestDispatcher dispatch;
		HttpSession session=request.getSession();
		String userName;
		String password;
		
		switch(path) {
		// restaurant login home page
		case "/Restaurants/home":
			userName = request.getParameter("userName");
			password = request.getParameter("password");
			Restaurant restaurant = restaurantService.getRestaurant(userName, password);
			session.setAttribute("restaurant", restaurant);
			
			dispatch=request.getRequestDispatcher("/jsp/restaurantOwner/restaurantOwnerHomePage.jsp");
			dispatch.forward(request, response);
			break;
		// food category CRUD operations
		case "/Restaurants/viewFoodCategory":
			restaurant=(Restaurant) session.getAttribute("restaurant");
			
			List<String> foodCategories = menuService.viewAllFoodCategory(restaurant.getRestaurantId());
			System.out.println(restaurant.getRestaurantId());
			request.setAttribute("foodCategories",foodCategories);
			session.setAttribute("foodCategories",foodCategories);
			
			dispatch=request.getRequestDispatcher("/jsp/restaurantOwner/viewFoodCategories.jsp");
			dispatch.forward(request, response);
			break;
			
		case "/Restaurants/selectedFoodCategory":
			String foodCategory = request.getParameter("update");
			request.setAttribute("selectedFoodCategory", foodCategory);
			dispatch=request.getRequestDispatcher("/jsp/restaurantOwner/editFoodCategory.jsp");
			dispatch.forward(request, response);
			break;
			
		case "/Restaurants/deleteFoodCategory":
			foodCategory=request.getParameter("delete");
			restaurant=(Restaurant) session.getAttribute("restaurant");
			menuService.deleteFoodCategory(foodCategory, restaurant.getRestaurantId());
			dispatch=request.getRequestDispatcher("viewFoodCategory");
			dispatch.forward(request, response);
			break;
		
		// food items CRUD operations
		case "/Restaurants/viewFoodItems":
			foodCategory=request.getParameter("foodItemsCategory");
			List<FoodItem> foodItemsList = foodService.getFoodItemsByCategory(foodCategory);
			request.setAttribute("foodItemsList", foodItemsList);
			dispatch=request.getRequestDispatcher("/jsp/restaurantOwner/viewFoodItems.jsp");
			dispatch.forward(request, response);
			break;
			
		case "/Restaurants/selectedFoodItem":
			int foodId = Integer.parseInt(request.getParameter("update"));
			FoodItem foodItem = foodService.getFoodById(foodId);
			request.setAttribute("selectedFoodItem", foodItem);
			dispatch=request.getRequestDispatcher("/jsp/restaurantOwner/editFoodItem.jsp");
			dispatch.forward(request, response);
			break;
			
		case "/Restaurants/deleteFoodItem":
			
			break;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getServletPath();
		RequestDispatcher dispatch;
		HttpSession session=request.getSession();
		
		
		
		switch(path) {
		case "/Restaurants/updateFoodCategory":
			String oldFoodCategory = (String) request.getParameter("oldFoodCategory");
			String newFoodCategory = request.getParameter("newFoodCategory");
			Restaurant restaurant=(Restaurant) session.getAttribute("restaurant");
			int flag = menuService.updateFoodCategory(restaurant.getRestaurantId(), oldFoodCategory, newFoodCategory);
			response.sendRedirect("viewFoodCategory");
			break;
			
		case "/Restaurants/addFoodItem":
			String foodName = request.getParameter("foodName");
			Double foodPrice = Double.parseDouble(request.getParameter("foodPrice"));
			Double offer = Double.parseDouble(request.getParameter("offer"));
			String category = request.getParameter("category");
			FoodItem foodItem=new FoodItem(0, foodName, category, foodPrice, offer);
			
			foodService.addFoodItem(foodItem);
			response.sendRedirect("viewFoodCategory");
			break;
			
		case "/Restaurants/updateFoodItem":
			int foodId = Integer.parseInt(request.getParameter("foodId"));
			foodName=request.getParameter("foodName");
			String foodCategory = request.getParameter("category");
			double price = Double.parseDouble(request.getParameter("price"));
			offer = Double.parseDouble(request.getParameter("offer"));
			FoodItem updatedFoodItem=new FoodItem(0, foodName, foodCategory, price, offer);
			foodService.updateFoodItem(updatedFoodItem, foodId);
			response.sendRedirect("viewFoodCategory");
			break;
		}
	}

	

}
