package com.cybage.service;

import java.util.List;

import com.cybage.pojo.RestaurantMenu;

public interface RestaurantMenuService {
	public String addRestaurantMenu(RestaurantMenu menu);
	public String deleteFoodCategory(String foodCategory, int restaurantId);
	public int updateFoodCategory(int restaurantId, String foodCategory, String newFoodCategory);
	public List<String> viewAllFoodCategory(int restaurantId);
}
