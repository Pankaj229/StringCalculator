package com.cybage.service;

import java.util.List;

import com.cybage.dao.RestaurantMenuDao;
import com.cybage.dao.RestaurantMenuDaoImpl;
import com.cybage.pojo.RestaurantMenu;

public class RestaurantMenuServiceImpl implements RestaurantMenuService {
	public static RestaurantMenuDao dao=new RestaurantMenuDaoImpl();
	@Override
	public String addRestaurantMenu(RestaurantMenu menu) {
		List<String> foodCategoryList = dao.viewAllCategories(menu.getRestaurantId());
		if(foodCategoryList.equals(menu.getFoodCategory())){
			return menu.getFoodCategory()+" already present in your menu list";
		}
		
		dao.addFoodCategory(menu);
		return menu.getFoodCategory()+" successfully added in your menu list.";
		
	}

	@Override
	public String deleteFoodCategory(String foodCategory, int restaurantId) {
		return dao.deleteFoodCategory(foodCategory, restaurantId);
	}

	@Override
	public int updateFoodCategory(int restaurantId, String foodCategory, String newFoodCategory) {
		return dao.updateFoodCategory(restaurantId, foodCategory, newFoodCategory);
	}

	@Override
	public List<String> viewAllFoodCategory(int restaurantId) {
		return dao.viewAllCategories(restaurantId);
	}

}
