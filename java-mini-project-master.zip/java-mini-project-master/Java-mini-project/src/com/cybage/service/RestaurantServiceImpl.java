package com.cybage.service;

import java.util.List;

import com.cybage.dao.RestaurantDao;
import com.cybage.dao.RestaurantDaoImpl;
import com.cybage.pojo.Restaurant;

public class RestaurantServiceImpl implements RestaurantService {
	public static RestaurantDao dao=new RestaurantDaoImpl();

	@Override
	public void addRestaurant(Restaurant restaurant) {
		List<Restaurant> list = dao.viewAllRestaurant();
		for (Restaurant eachRestaurant : list) {
			if(eachRestaurant.getRestuarantName().equals(restaurant.getRestuarantName()) && 
					eachRestaurant.getPincode()==restaurant.getPincode()) {
				System.out.println("Restaurant is already present in out database...");
				return;
				
			}
		}
		dao.addRestaurant(restaurant);
		
	}

	@Override
	public void deleteRestaurant(int restaurantId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Restaurant updateRestaurant(Restaurant restaurant) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Restaurant viewRestaurant(String restaurantName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Restaurant> viewAllResataurant() {
		return dao.viewAllRestaurant();
	}
	
	@Override
	public Restaurant getRestaurant(String userName, String password) {
		return dao.getRestaurant(userName, password);
	}

}
