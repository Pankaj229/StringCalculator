package com.cybage.service;

import java.util.List;

import com.cybage.pojo.Restaurant;

public interface RestaurantService {
	public void addRestaurant(Restaurant restaurant);
	public void deleteRestaurant(int restaurantId);
	public Restaurant updateRestaurant(Restaurant restaurant);
	public Restaurant viewRestaurant(String restaurantName);
	public List<Restaurant> viewAllResataurant();
	
	public Restaurant getRestaurant(String userName, String password);
}
