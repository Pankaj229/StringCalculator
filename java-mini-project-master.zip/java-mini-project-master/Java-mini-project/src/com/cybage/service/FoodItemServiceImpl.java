package com.cybage.service;

import java.util.List;

import com.cybage.dao.FoodItemDao;
import com.cybage.dao.FoodItemDaoImpl;
import com.cybage.pojo.FoodItem;

public class FoodItemServiceImpl implements FoodItemService {
	public FoodItemDao dao=new FoodItemDaoImpl();
	@Override
	public List<FoodItem> getFoodItemsByCategory(String foodCategory) {
		return dao.getFoodItemsByCategory(foodCategory);
	}
	@Override
	public void addFoodItem(FoodItem foodItem) {
		dao.addFoodItem(foodItem);
	}
	@Override
	public FoodItem getFoodById(int foodId) {
		return dao.getFoodById(foodId);
	}
	@Override
	public void updateFoodItem(FoodItem foodItem, int foodId) {
		dao.updateFoodItem(foodItem, foodId);
	}
}
