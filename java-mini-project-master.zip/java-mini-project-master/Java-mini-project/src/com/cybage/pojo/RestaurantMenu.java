package com.cybage.pojo;

public class RestaurantMenu {
	private int restaurantId;
	private int foodId;
	private String foodCategory;
	public RestaurantMenu() {
		// TODO Auto-generated constructor stub
	}
	public RestaurantMenu(int restaurantId, int foodId, String foodCategory) {
		this.restaurantId = restaurantId;
		this.foodId = foodId;
		this.foodCategory = foodCategory;
	}
	public int getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public String getFoodCategory() {
		return foodCategory;
	}
	public void setFoodCategory(String foodCategory) {
		this.foodCategory = foodCategory;
	}
	@Override
	public String toString() {
		return "restaurantId=" + restaurantId + ", foodId=" + foodId + ", foodCategory=" + foodCategory;
	}
	
}
