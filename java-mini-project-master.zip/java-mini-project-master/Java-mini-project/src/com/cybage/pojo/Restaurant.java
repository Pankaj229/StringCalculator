package com.cybage.pojo;

public class Restaurant {
	private int restaurantId;
	private String restuarantName;
	private String restaurantUserName;
	private String restaurantPassword;
	private int pincode;
	public Restaurant(String restuarantName, String restaurantUserName, String restaurantPassword,
			int pincode) {
		this.restuarantName = restuarantName;
		this.restaurantUserName = restaurantUserName;
		this.restaurantPassword = restaurantPassword;
		this.pincode = pincode;
	}
	public Restaurant() {
		
	}
	public int getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getRestuarantName() {
		return restuarantName;
	}
	public void setRestuarantName(String restuarantName) {
		this.restuarantName = restuarantName;
	}
	public String getRestaurantUserName() {
		return restaurantUserName;
	}
	public void setRestaurantUserName(String restaurantUserName) {
		this.restaurantUserName = restaurantUserName;
	}
	public String getRestaurantPassword() {
		return restaurantPassword;
	}
	public void setRestaurantPassword(String restaurantPassword) {
		this.restaurantPassword = restaurantPassword;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	@Override
	public String toString() {
		return "restaurantId=" + restaurantId + ", restuarantName=" + restuarantName
				+ ", restaurantUserName=" + restaurantUserName + ", restaurantPassword=" + restaurantPassword
				+ ", pincode=" + pincode;
	}
	
	
}
