package com.cybage.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cybage.pojo.Restaurant;
import com.cybage.pojo.RestaurantMenu;
import com.cybage.util.DBUtil;

public class RestaurantMenuDaoImpl implements RestaurantMenuDao {
	
	@Override
	public void addFoodCategory(RestaurantMenu menu) {
		String sql="insert into restaurant_menu values(?,?,?)";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setInt(1, menu.getRestaurantId());
			statement.setInt(2, menu.getFoodId());
			statement.setString(3, menu.getFoodCategory());
			
			statement.executeUpdate();
			System.out.println("food category added successfully");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public String deleteFoodCategory(String foodCategory, int restaurantId) {
		String sql="delete from restaurant_menu where food_category=? and rest_id=?";
		int deletedItems=0;
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setString(1, foodCategory);
			statement.setInt(2, restaurantId);
			
			deletedItems = statement.executeUpdate();
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return foodCategory+" food category is deleted and number of food items deleted are "+deletedItems;
		
	}

	@Override
	public int updateFoodCategory(int restaurantId, String oldfoodCategory, String newFoodCategory) {
		String sql="update restaurant_menu set food_category=? where rest_id=? and food_category=?";
		int rowsUpdated=-1;
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setString(1, newFoodCategory);
			statement.setInt(2, restaurantId);
			statement.setString(3, oldfoodCategory);
			
			rowsUpdated = statement.executeUpdate();
			System.out.println("food category updated successfully");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowsUpdated;
	}

	@Override
	public List<String> viewAllCategories(int restaurantId) {
		List<String> menuList=new ArrayList<String>();
		String sql="select distinct food_category from restaurant_menu where rest_id=?";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setInt(1, restaurantId);
			ResultSet result = statement.executeQuery();
			while(result.next()) {
				menuList.add(result.getString(1));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return menuList;
	}

}
