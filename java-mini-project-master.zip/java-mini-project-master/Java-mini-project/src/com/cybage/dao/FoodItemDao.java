package com.cybage.dao;

import java.util.List;

import com.cybage.pojo.FoodItem;

public interface FoodItemDao {
	public List<FoodItem> getFoodItemsByCategory(String foodCategory);
	public void addFoodItem(FoodItem foodItem);
	public FoodItem getFoodById(int foodId);
	public void updateFoodItem(FoodItem foodItem, int foodId);
}
