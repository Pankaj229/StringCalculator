package com.cybage.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cybage.pojo.FoodItem;
import com.cybage.util.DBUtil;

public class FoodItemDaoImpl implements FoodItemDao {

	@Override
	public List<FoodItem> getFoodItemsByCategory(String foodCategory) {
		List<FoodItem> foodList=new ArrayList<>();
		String sql="select * from food_menu where food_category=?";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setString(1, foodCategory);
			ResultSet result = statement.executeQuery();
			while(result.next()) {
				FoodItem foodItem=new FoodItem();
				foodItem.setFoodId(result.getInt(1));
				foodItem.setFoodName(result.getString(2));
				foodItem.setFoodCategory(result.getString(3));
				foodItem.setPrice(result.getDouble(4));
				foodItem.setOffer(result.getDouble(5));
				System.out.println("food item: "+foodItem);
				foodList.add(foodItem);
			}
			System.out.println("food List: "+foodList);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return foodList;
	}
	
	@Override
	public void addFoodItem(FoodItem foodItem) {
		String sql="insert into food_menu values(?,?,?,?,?)";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setInt(1, foodItem.getFoodId());
			statement.setString(2, foodItem.getFoodName());
			statement.setString(3, foodItem.getFoodCategory());
			statement.setDouble(4, foodItem.getPrice());
			statement.setDouble(5, foodItem.getOffer());
			
			int flag = statement.executeUpdate();
			System.out.println("food Item added successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public FoodItem getFoodById(int foodId) {
		String sql="select * from food_menu where food_id=?";
		FoodItem foodItem=new FoodItem();
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setInt(1, foodId);
			ResultSet result = statement.executeQuery();
			while(result.next()) {
				foodItem.setFoodId(result.getInt(1));
				foodItem.setFoodName(result.getString(2));
				foodItem.setFoodCategory(result.getString(3));
				foodItem.setPrice(result.getDouble(4));
				foodItem.setOffer(result.getDouble(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return foodItem;
	}
	
	@Override
	public void updateFoodItem(FoodItem foodItem, int foodId) {
		String sql="update food_menu set food_name=?, food_category=?, price=?, offer=? where food_id=?";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setString(1, foodItem.getFoodName());
			statement.setString(2, foodItem.getFoodCategory());
			statement.setDouble(3, foodItem.getPrice());
			statement.setDouble(4, foodItem.getOffer());
			statement.setInt(5, foodId);
			
			statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
}
