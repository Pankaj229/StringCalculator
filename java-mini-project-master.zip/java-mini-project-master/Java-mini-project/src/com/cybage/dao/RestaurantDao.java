package com.cybage.dao;

import java.util.List;

import com.cybage.pojo.Restaurant;

public interface RestaurantDao {
	public void addRestaurant(Restaurant restaurant);
	public void deleteRestaurant(int restaurantId);
	public Restaurant updateRestuarant(Restaurant restaurant);
	public Restaurant viewRestaurant(String restaurantName);
	public List<Restaurant> viewAllRestaurant();
	
	public Restaurant getRestaurant(String userName, String password);
}
