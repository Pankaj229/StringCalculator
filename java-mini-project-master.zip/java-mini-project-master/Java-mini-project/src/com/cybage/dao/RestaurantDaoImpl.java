package com.cybage.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cybage.pojo.Restaurant;
import com.cybage.util.DBUtil;

public class RestaurantDaoImpl implements RestaurantDao {
	@Override
	public void addRestaurant(Restaurant restaurant) {
		
		String sql="insert into restaurant values(?,?,?,?,?)";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setInt(1, restaurant.getRestaurantId());
			statement.setString(2, restaurant.getRestuarantName());
			statement.setString(3, restaurant.getRestaurantUserName());
			statement.setString(4, restaurant.getRestaurantPassword());
			statement.setInt(5, restaurant.getPincode());
			
			statement.executeUpdate();
			System.out.println("Restaurant added successfully");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteRestaurant(int restaurantId) {
		
		
	}

	@Override
	public Restaurant updateRestuarant(Restaurant restaurant) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Restaurant viewRestaurant(String restaurantName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Restaurant> viewAllRestaurant() {
		List<Restaurant> restaurantList=new ArrayList<Restaurant>();
		String sql="select * from restaurant";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			ResultSet result = statement.executeQuery();
			while(result.next()) {
				Restaurant restaurant=new Restaurant();
				restaurant.setRestaurantId(result.getInt(1));
				restaurant.setRestuarantName(result.getString(2));
				restaurant.setRestaurantUserName(result.getString(3));
				restaurant.setRestaurantPassword(result.getString(4));
				restaurant.setPincode(result.getInt(5));
				restaurantList.add(restaurant);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return restaurantList;
	}
	
	@Override
	public Restaurant getRestaurant(String userName, String password) {
		Restaurant restaurant=new Restaurant();
		String sql="select * from restaurant where rest_username=? and rest_password=?";
		try {
			PreparedStatement statement = DBUtil.getConnection().prepareStatement(sql);
			statement.setString(1, userName);
			statement.setString(2, password);
			
			ResultSet result = statement.executeQuery();
			while(result.next()) {
				restaurant.setRestaurantId(result.getInt(1));
				restaurant.setRestuarantName(result.getString(2));
				restaurant.setRestaurantUserName(result.getString(3));
				restaurant.setRestaurantPassword(result.getString(4));
				restaurant.setPincode(result.getInt(5));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return restaurant;
	}

}
